#ifndef APT_COMPILING_APT
#error Internal header without ABI stability. Should only be used by apt itself!
#endif
